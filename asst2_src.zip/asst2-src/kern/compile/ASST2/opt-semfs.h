/* Automatically generated; do not edit */
#ifndef _OPT_SEMFS_H_
#define _OPT_SEMFS_H_
#define OPT_SEMFS 1
#endif /* _OPT_SEMFS_H_ */
