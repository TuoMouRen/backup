import java.util.ArrayList;

public class Cinema {
	
	public Cinema(String[] words) {
		this.setCinemaID(words[1]);
	}
	
	/**
	 * add row to rows
	 * @param rowID
	 * @param seatNumber
	 */
	public void addRow(String rowID,int seatNumber){
		Row aRow = new Row(rowID,seatNumber);
		rows.add(aRow);
	}
	
	//gets and sets
	public String getCinemaID() {
		return cinemaID;
	}
	public void setCinemaID(String cinemaID) {
		this.cinemaID = cinemaID;
	}
	
	public ArrayList<Row> getRows() {
		return rows;
	}

	public void setRows(ArrayList<Row> rows) {
		this.rows = rows;
	}

	private ArrayList<Row> rows = new ArrayList<Row>();
	private String cinemaID;
}
