
public class Cancel {
	
	public Cancel (String[] words) {
		this.setRequestID(Integer.parseInt(words[1]));
	}

	/**
	 * cancel a request
	 * @param r
	 * @param s
	 */
	public void cancelRequest (Request r, Session s) {
		
		s.reset(r.getTempBookingRow(),r.getRequestID());
			
	}
	
	
	//gets and sets
	public int getRequestID() {
		return requestID;
	}

	public void setRequestID(int requestID) {
		this.requestID = requestID;
	}

	private int requestID;
}
