import java.util.ArrayList;

public class Row {

	public Row(String rowID, int seatNumber) {
		this.setRowID(rowID);
		this.setSeatNumber(seatNumber);
		for (int i=0;i<seatNumber;i++) {
			seats.add(0);
		}
	}
	
	
	
	/**
	 * Book seats with tickets number
	 * check first;
	 * @param r
	 * @return
	 */
	public boolean change(Request r) {
		int i,j =0;
		for (i=0;i<seatNumber;i++) {
			if (seats.get(i) == 0 ) {
				if (checkAvailable(r.getTickets(),i)) {
					break;
				}
			}
		}
		if (i != seatNumber){
			
			for (j=i; j<i+r.getTickets(); j++) {
				seats.set(j,r.getRequestID());
			}
			r.setTempBookingSeatStart(i+1);
			r.setTempBookingSeatEnd(j);	
			return true;
		}
		return false;
	}
	
	/**
	 * check how many seats in current index are empty and in consecutive  
	 * @param tickets
	 * @param index
	 * @return
	 */
	public boolean checkAvailable(int tickets, int index) {
		int count = 0;
		for (int i=index; i<seatNumber; i++) {
			if (seats.get(i) == 0) {
				count++;
			}else {
				break;
			}
		}
		if (count >= tickets) {
			return true;
		}
		return false;
	}

	/**
	 * reset the *requestID request to empty
	 * @param requestID
	 */
	
	public void reset(int requestID) {
		for (int i=0;i<seatNumber;i++) {
			
			if (requestID == seats.get(i)) {
				seats.set(i,0);
			}
		}
	}
	
	public void rowPrint() {
		int check = -1;
		int count = 0;
		int start = 0;
		int first = 0;
		for (int i=0;i<seats.size();i++) {
			
				if (first == 0) { //first request start count (print with no ",")
						if (check == seats.get(i) && i+1 != seats.size()) { //continue count same seats from same request							
								count++;						
						}else {	//start count
							if (count == 0) { //start a new request
								check = seats.get(i);								
								start = i+1;
								count = 1;
							}else if (count == 1 && check != 0) {//only one ticket
								first = 1;
								System.out.print(this.getRowID() + start);
								check = seats.get(i);
								start = i+1;
								count = 1;
							}else if (check != 0){ //many tickets
								first = 1;
								System.out.print(this.getRowID() + start +
										"-" + this.getRowID() + (start+count-1) );
								check = seats.get(i);
								start = i+1;
								count = 1;
							}else if (check == 0) {
								check = seats.get(i);
								start = i+1;
								count = 1;
							}					
						}
						
				}else {	//other requests
						if (check == seats.get(i) && i+1 != seats.size()) { //continue count same seats from same request	
								count++;							
						}else {//start count							
							if (count == 0) { //start a new request
								check = seats.get(i);
								start = i+1;
								count = 1;
							}else if (count == 1 && check != 0) {//only one ticket
								System.out.print("," + this.getRowID() + start);
								check = seats.get(i);
								start = i+1;
								count = 1;
							}else if (check != 0) { //many tickets
								System.out.print("," + this.getRowID() + start +
										"-" + this.getRowID() + (start+count-1) );
								check = seats.get(i);
								start = i+1;
								count = 1;
							}else if (check == 0) {
								check = seats.get(i);
								start = i+1;
								count = 1;
							}
						}
				}
			
			
			
		}
	}
	
	/**
	 * check if no seats have been booked in this row
	 * @return
	 */
	
	public boolean emptyCheck() {
		for (int i=0;i<seats.size();i++) {
			if (seats.get(i) != 0) {
				return true;
			}
		}
		return false;
	}
	
	
	public String getRowID() {
		return rowID;
	}

	public void setRowID(String rowID) {
		this.rowID = rowID;
	}

	public int getSeatNumber() {
		return seatNumber;
	}

	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}

	public ArrayList<Integer> getSeats() {
		return seats;
	}

	public void setSeats(ArrayList<Integer> seats) {
		this.seats = seats;
	}

	private String rowID;
	private int seatNumber;
	private ArrayList<Integer> seats = new ArrayList<Integer>();
	
}
