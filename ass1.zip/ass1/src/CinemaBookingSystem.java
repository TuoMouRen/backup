import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class CinemaBookingSystem {

	


	public static void main(String[] args) { 
		
		  ArrayList<Cinema> cinemas = new ArrayList<Cinema>(); 
		  ArrayList<Session> sessions = new ArrayList<Session>();
		  ArrayList<Request> requests = new ArrayList<Request>();
		 
            Scanner sc = null;
	        try
	        {
	            sc = new Scanner(new File(args[0]));    // args[0] is the first command line argument
				while (sc.hasNext()) {
					String s = sc.nextLine();
					String[] words = s.split(" ");
					
					if (words[0].equalsIgnoreCase("Cinema")) {	
						cinemas = createCinemas(words,cinemas);						
					}else if (words[0].equalsIgnoreCase("Session")){
						sessions = crateSessions(words,sessions,cinemas);
					}else if (words[0].equalsIgnoreCase("Request")){
						int temp = requests.size();
						requests = createRequests(words,requests,sessions);
						printRequest(temp,requests);
					}else if (words[0].equalsIgnoreCase("Change")){					
						makeChange(words,requests,sessions);						
					}else if (words[0].equalsIgnoreCase("Cancel")) {
						makeCancel(words,requests,sessions);
					}else if (words[0].equalsIgnoreCase("Print")) {
						makePrint(words,sessions);
					}
				}
	      }
	      catch (FileNotFoundException e)
	      {
	          System.out.println(e.getMessage());
	      }
	      finally
	      {
	          if (sc != null) sc.close();
	      }
	        
	}

	
	
////////////////////////////////////////////////////////////////////////////////////////create ArrayList 	
	/**
	 * add the cinemaInfo into the cinemaList 
	 * avoid duplicate 
	 * @param words
	 * @param cinemas
	 * @return cinemas
	 */
	private static ArrayList<Cinema> createCinemas(String[] words,ArrayList<Cinema> cinemas) {
		Cinema c = new Cinema(words);
		int count = cinemas.size();
		//empty case
		if (count == 0) { 
			c.addRow(words[2],Integer.parseInt(words[3]));
			cinemas.add(c);
			
		}else {		
		    for (int i=0; i <count; i++) {
				if (cinemas.get(i).getCinemaID().equals(words[1])){
					cinemas.get(i).addRow(words[2],Integer.parseInt(words[3]));
					return cinemas;
		        }
				
		    }
		    c.addRow(words[2],Integer.parseInt(words[3]));
	        cinemas.add(c);      	
		}
		
		return cinemas;
	}
		
	/**
	 * add the sessionInfo into the sessionList
	 * including rows information replication
	 * @param words
	 * @param sessions
	 * @param cinemas
	 * @return sessions
	 */
	public static ArrayList<Session> crateSessions(String[] words,ArrayList<Session> sessions,ArrayList<Cinema> cinemas) {
		Session s = new Session(words);
		for (int i=0; i<cinemas.size(); i++) {	
			if (s.getCinemaID().equals(cinemas.get(i).getCinemaID())) {			
				s.cloneRows(cinemas.get(i).getRows());
				break;
			}
		}
		
		sessions.add(s);		
		return sessions;	
		
	}	
	
	
	
////////////////////////////////////////////////////////////////////////////////////////Request	
	/**
	 * add requests to arrayList
	 * and make request
	 * @param words
	 * @param requests
	 * @param sessions
	 * @return requests
	 */
	
	public static ArrayList<Request> createRequests(String[] words, ArrayList<Request> requests,ArrayList<Session> sessions){
		Request r = new Request(words);
		
		if (bookForRequests(r,sessions)) {
			requests.add(r);
		}
		return requests;
	}
	

	/**
	 * find the right session to build request
	 * check cinemaID and time
	 * call bookSeast in Session class
	 * @param r
	 * @param sessions
	 * @return true if request success
	 * 		   false if request failed
	 */
	public static boolean bookForRequests(Request r,ArrayList<Session> sessions) {
        for(int i=0;i<sessions.size();i++)  {

        	if (r.getCinemaID().equals(sessions.get(i).getCinemaID()) && r.getTime().equals(sessions.get(i).getTime())) {

        		if (sessions.get(i).bookSeats(r)) {
        			
        			return true;
        		}
        	}
        }

		return false;
	}
		
	/**
	 * simply print formal output about booking 
	 * print the last value in requests arrayList
	 * @param temp
	 * @param requests
	 */
	public static void printRequest(int temp,ArrayList<Request> requests) {
		if (temp+1 == requests.size()){
			if (requests.get(requests.size()-1).getTickets() == 1) {			
				System.out.println( "Booking " + requests.get(requests.size()-1).getRequestID() + " " + 
				requests.get(requests.size()-1).getTempBookingRow() + 
			  	requests.get(requests.size()-1).getTempBookingSeatStart());
		  	}else {
		  		System.out.println( "Booking " + requests.get(requests.size()-1).getRequestID() + " " + 
		  		requests.get(requests.size()-1).getTempBookingRow() + 
			  	requests.get(requests.size()-1).getTempBookingSeatStart() + "-" + 
			  	requests.get(requests.size()-1).getTempBookingRow() + 
			  	requests.get(requests.size()-1).getTempBookingSeatEnd());
		  	}
		}else {
			System.out.println("Booking rejected");
		}
		
	}

	
	
	
////////////////////////////////////////////////////////////////////////////////////////Change	
	/**
	 * change by inputs and print result 
	 * @param words
	 * @param requests
	 * @param sessions
	 */
	public static void makeChange(String[] words,ArrayList<Request> requests,ArrayList<Session> sessions) {
		Change c = new Change(words);
		Request r = findRequest(requests,c.getRequestID());

		Session after = findSession(sessions,c.getCinemaID(),c.getTime());
		Session pre = null; 
		if (r != null) {
			pre = findSession(sessions,r.getCinemaID(),r.getTime());
		}
		if ( r != null && after != null && pre != null ) {
			if( c.changeRequest(r,pre,after,c.getCinemaID(),c.getTickets()) ) {
				//update request Info.
				r.setTime(c.getTime());
				if (r.getTickets() == 1) {
					System.out.println( "Change " + r.getCinemaID() + " " + r.getTempBookingRow() + 
					r.getTempBookingSeatStart());
				}else {
				  	System.out.println( "Change " + r.getCinemaID() + " " + r.getTempBookingRow() + 
				  	r.getTempBookingSeatStart() + "-" + 
				  	r.getTempBookingRow() + 
				  	r.getTempBookingSeatEnd());
				}
			}else {
				System.out.println("Change rejected");
			}
		}else {
			System.out.println("Change rejected");
		}
	}
	
	
	
	
////////////////////////////////////////////////////////////////////////////////////////Cancel	
	/**
	 * cancel by requestID and print result
	 * @param words
	 * @param requests
	 * @param sessions
	 */
	public static void makeCancel(String[] words,ArrayList<Request> requests, ArrayList<Session> sessions) {
		Cancel c = new Cancel(words);
		Request r = findRequest(requests,c.getRequestID());
		if (r != null) {
			
			Session s = findSession(sessions,r.getCinemaID(),r.getTime());
			c.cancelRequest(r, s);
			removeRequest(requests,c.getRequestID());
			System.out.println("Cancel " + c.getRequestID());
		}else {
			System.out.println("Cancel rejected");
		}			
	}
	/**
	 * remove request in request array after cancel  
	 * @param requests
	 * @param requestID
	 */
	public static void removeRequest(ArrayList<Request> requests, int requestID) {
        for(int i=0;i<requests.size();i++)  {

        	if (requestID == requests.get(i).getRequestID()) {
        		requests.remove(i);
        		break;
        	}
        }
	}
	
	
	
////////////////////////////////////////////////////////////////////////////////////////Print
	/**
	 * prints command
	 * @param words
	 * @param sessions
	 */
	public static void makePrint(String[] words, ArrayList<Session> sessions) {
		
		Session s = findSession(sessions,words[1],words[2]);
		System.out.println(s.getMovie());
    	s.printSession();
	}
	
	
	

	
////////////////////////////////////////////////////////////////////////////////////////Find value in arrayList	
	/**
	 * find a request in arrayList by Id
	 * @param requests
	 * @param requestID
	 * @return r
	 */
	public static Request findRequest(ArrayList<Request> requests, int requestID) {
		Request r = null;
        for(int i=0;i<requests.size();i++)  {

        	if (requestID == requests.get(i).getRequestID()) {
        		r = requests.get(i);
        		break;
        	}
        }
		return r;
	}
	/**
	 * find a session in arrayList by Id
	 * @param sessions
	 * @param cinemaID
	 * @param time
	 * @return s
	 */
	public static Session findSession(ArrayList<Session> sessions, String cinemaID, String time) {
		Session s = null;
        for(int i=0;i<sessions.size();i++)  {

        	if (cinemaID.equals(sessions.get(i).getCinemaID()) && time.equals(sessions.get(i).getTime())) {
        		s = sessions.get(i);
        		break;
        	}
        }
		return s;
		
	}
	
	
}

