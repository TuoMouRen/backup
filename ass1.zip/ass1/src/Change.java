
public class Change extends Request {

	public Change(String[] words) {
		super(words);
	}
	
	
	/**
	 * reset seats
	 * change request details
	 * 
	 * @param r
	 * @param s
	 * @param cinemaIDtoChange
	 * @param ticketsToChange
	 * @return
	 */
	public boolean changeRequest (Request r, Session pre, Session after, String cinemaIDtoChange, int ticketsToChange) {
		if (after.checkSeatsCapacity(ticketsToChange) ) {
			pre.reset(r.getTempBookingRow(),r.getRequestID());	
			r.setCinemaID(cinemaIDtoChange);
			r.setTickets(ticketsToChange);
			return after.bookSeats(r);
		}
		return false;
	}
		

}