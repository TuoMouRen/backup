
public class Request {

	public Request(String[] words) {
		this.setRequestID(Integer.parseInt(words[1]));
		this.setCinemaID(words[2]);
		this.setTime(words[3]);
		this.setTickets(Integer.parseInt(words[4]));
	}

	
//some gets and sets for objects
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
//
	public int getTickets() {
		return tickets;
	}
	public void setTickets(int tickets) {
		this.tickets = tickets;
	}
//
	public String getCinemaID() {
		return cinemaID;
	}
	public void setCinemaID(String cinemaID) {
		this.cinemaID = cinemaID;
	}
//
	public int getRequestID() {
		return requestID;
	}
	public void setRequestID(int requestID) {
		this.requestID = requestID;
	}
//	
	public String getTempBookingRow() {
		return tempBookingRow;
	}
	public void setTempBookingRow(String tempBookingRow) {
		this.tempBookingRow = tempBookingRow;
	}
//
	public int getTempBookingSeatStart() {
		return tempBookingSeatStart;
	}

	public void setTempBookingSeatStart(int tempBookingSeatStart) {
		this.tempBookingSeatStart = tempBookingSeatStart;
	}
//
	public int getTempBookingSeatEnd() {
		return tempBookingSeatEnd;
	}
	public void setTempBookingSeatEnd(int tempBookingSeatEnd) {
		this.tempBookingSeatEnd = tempBookingSeatEnd;
	}

	// temp store booking information
	private String tempBookingRow;
	private int tempBookingSeatStart;
	private int tempBookingSeatEnd;
	
	private String time;
	private int tickets;
	private String cinemaID;
	private int requestID;
}
