import java.util.ArrayList;

public class Session {
	public Session(String[] words) {
		this.setCinemaID(words[1]);
		this.setTime(words[2]);
		this.setMovie(words[3]);		
	}
	
	/**
	 * copy a same rows and seats size rows array in session 
	 * @param rows
	 */
	public void cloneRows(ArrayList<Row> rows) {
		for (int i=0; i<rows.size(); i++) {
			Row aRow = new Row(rows.get(i).getRowID(),rows.get(i).getSeatNumber());
			this.getRows().add(aRow);
		}
	}
	/**
	 * judge whether change is available or not
	 * find a large enough row to book tickets 
	 * @param r
	 * @return
	 */
	public boolean bookSeats(Request r) {
		
		for (int i=0; i<rows.size(); i++) {
			if (rows.get(i).getSeatNumber() >= r.getTickets()) {
				
				if (rows.get(i).change(r)) {
					r.setTempBookingRow(rows.get(i).getRowID());
					return true;
				}
			}
		}
		return false;
		
	}
	
	/**
	 * print command
	 */
	public void printSession() {
		for (int i=0; i<rows.size(); i++) {
			if (rows.get(i).emptyCheck()) {
				System.out.print(rows.get(i).getRowID()+":"+" ");
				rows.get(i).rowPrint();
				System.out.print("\n");
			}
		}
	}
	
	/**
	 * cancel booking by requestID
	 * @param tempBookingRow
	 * @param requestID
	 */
	public void reset(String tempBookingRow,int requestID) {
		for (int i=0;i<rows.size();i++) {
			if (rows.get(i).getRowID().equals(tempBookingRow)) {
				rows.get(i).reset(requestID);
			}
		}
	}
	
	/**
	 * check if the tickets can fit the whole row 
	 * @param ticket
	 * @return
	 */
	
	public boolean checkSeatsCapacity(int ticket) {
		
		for (int i=0; i<rows.size(); i++) {
			if (rows.get(i).getSeatNumber() >= ticket) {
				return true;
			}
					
		}
		return false;
	}

	
	
	
	//gets and sets
	public String getCinemaID() {
		return cinemaID;
	}
	public void setCinemaID(String cinemaID) {
		this.cinemaID = cinemaID;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getMovie() {
		return movie;
	}

	public void setMovie(String movie) {
		this.movie = movie;
	}

	public ArrayList<Row> getRows() {
		return rows;
	}

	public void setRows(ArrayList<Row> rows) {
		this.rows = rows;
	}


	private ArrayList<Row> rows = new ArrayList<Row>();
	private String cinemaID;
	private String time;
	private String movie;
}
